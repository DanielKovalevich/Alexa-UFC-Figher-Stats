# Alexa-UFC-Figher-Stats

I've always been a big fan of MMA and getting fighter stats right away would be really nice. This is also for Amazon's current promotion.
